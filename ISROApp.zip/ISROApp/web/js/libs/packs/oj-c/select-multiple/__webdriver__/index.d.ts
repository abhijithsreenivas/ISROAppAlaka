import { By } from 'selenium-webdriver';
import { DriverLike } from '@oracle/oraclejet-webdriver';
import { SelectMultipleWebElement } from './SelectMultipleWebElement';
export { SelectMultipleWebElement };
/**
 * Retrieve an instance of [[SelectMultipleWebElement]].
 * @example
 * ```javascript
 * import { findSelectMultiple } from '@oracle/oraclejet-core-pack/webdriver';
 * const el = await findSelectMultiple(driver, By.id('my-oj-c-select-multiple'));
 * ```
 * @param driver A WebDriver/WebElement instance from where the element will be
 * searched. If WebDriver is passed, the element will be searched globally in the
 * document. If WebElement is passed, the search will be relative to this element.
 * @param by The locator with which to find the element
 */
export declare function findSelectMultiple(driver: DriverLike, by: By): Promise<SelectMultipleWebElement>;
