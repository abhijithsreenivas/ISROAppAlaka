export { InputPassword } from './input-password';
export { CInputPasswordElement } from './input-password';