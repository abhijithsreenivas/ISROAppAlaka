export { LegendSection } from './legend-section';
export { CLegendSectionElement } from './legend-section';