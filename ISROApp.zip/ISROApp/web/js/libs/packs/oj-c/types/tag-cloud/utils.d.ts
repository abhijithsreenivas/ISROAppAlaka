export declare function transformItem(dataItem: any): {
    color: any;
    accessibleLabel: any;
    value: any;
    label: any;
    id: any;
};
export declare function executeLink(dest: string): void;
