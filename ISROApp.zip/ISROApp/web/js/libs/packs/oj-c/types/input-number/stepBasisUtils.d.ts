export declare function determineSteppedValue(step: number, stepOpt: number, currentParsedValue: number, initialValue?: number, maxOpt?: number, minOpt?: number): number;
