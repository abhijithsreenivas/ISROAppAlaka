export { HighlightText } from './highlight-text';
export { CHighlightTextElement } from './highlight-text';