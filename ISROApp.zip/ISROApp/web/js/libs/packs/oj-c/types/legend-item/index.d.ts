export { LegendItem, LegendItemProps } from './legend-item';
export { CLegendItemElement } from './legend-item';