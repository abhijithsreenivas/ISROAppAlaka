export { Legend } from './legend';
export { CLegendElement } from './legend';